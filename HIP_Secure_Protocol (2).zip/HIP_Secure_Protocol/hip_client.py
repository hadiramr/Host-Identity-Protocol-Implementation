# HIP CLIENT
import socket
import time
import json
import os
from getpass import getpass
from base64 import urlsafe_b64encode
from cryptography.hazmat.primitives.asymmetric import rsa, padding, dh
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.fernet import Fernet

# === Fixed Diffie-Hellman Parameters ===
p = 2519590847565789349402718324004839857142928212620403202777713783604366202070759555626401852588078440691829064124951508218929855914917618450280848912758392633350850486082503930213321971551843063545500766673908617593525182829993040236049972524680845987273644695848653836736222626099122601693782010622984120347394363468044014408222130009845555658623433121802679051141594073839663606610317485960492215434709781135998552808243411003983272624503216659472011801816960853891007731014711686793579401630497914243974060802491832576930476144771624050435640144319136100035173406172387
g = 2
parameter_numbers = dh.DHParameterNumbers(p, g)
dh_parameters = parameter_numbers.parameters()

# File where users' credentials and roles are stored
USERS_FILE = "users.json"

# Load all registered users from JSON file
def load_users():
    if not os.path.exists(USERS_FILE):
        return {}
    with open(USERS_FILE, "r") as f:
        return json.load(f)

# Save users data to JSON file
def save_users(users):
    with open(USERS_FILE, "w") as f:
        json.dump(users, f, indent=4)

# Write activity logs for client operations
def write_client_log(msg):
    with open("client_log.txt", "a", encoding="utf-8") as log:
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        log.write(f"[{timestamp}] {msg}\n")

# Digitally sign a message using RSA private key
def sign(private_key, message):
    return private_key.sign(
        message,
        padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
        hashes.SHA256()
    )

# Derive a symmetric session key using Diffie-Hellman key exchange
def derive_shared_key(private_key, peer_public_key):
    shared_key = private_key.exchange(peer_public_key)
    return HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=None,
        info=b'hip key exchange'
    ).derive(shared_key)

# Register new user (always assigned role = "guest")
def sign_up():
    users = load_users()
    print("\n Sign Up:")
    username = input(" New Username: ").strip()

    if username in users:
        print("[SignUp ] Username already exists.")
        return None

    password = getpass(" Password: ")

    role = "guest"
    users[username] = {"password": password, "role": role}
    save_users(users)

    print(f"[SignUp ] Account created as GUEST: {username}")
    write_client_log(f"New guest user signed up: {username}")
    return username

## Authenticate user, perform handshake, and start session
def login_and_connect():
    users = load_users()
    username = input(" Username: ").strip()
    password = getpass(" Password: ")

    if username not in users or users[username]["password"] != password:
        print("[Client] Invalid username or password")
        write_client_log(f"Login FAILED for username: '{username}'")
        return

    role = users[username]["role"]

    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    public_key = private_key.public_key()

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect(('localhost', 8900))

            public_bytes = public_key.public_bytes(
                serialization.Encoding.DER,
                serialization.PublicFormat.SubjectPublicKeyInfo
            )
            s.sendall(public_bytes)

            server_hi = s.recv(4096)
            server_public = serialization.load_der_public_key(server_hi)

            dh_priv = dh_parameters.generate_private_key()
            client_dh_pub = dh_priv.public_key()

            server_dh_bytes = s.recv(4096)
            server_dh_pub = serialization.load_pem_public_key(server_dh_bytes)

            s.sendall(client_dh_pub.public_bytes(
                serialization.Encoding.PEM,
                serialization.PublicFormat.SubjectPublicKeyInfo
            ))

            session_key = derive_shared_key(dh_priv, server_dh_pub)
            write_client_log(f"Session Key generated for user '{username}'")

            session_start = time.time()
            print("Session started. You have 5 minutes.")

            while True:
                if time.time() - session_start > 300:
                    print("Session expired after 5 minutes. Please login again.")
                    write_client_log(f"Session expired for user '{username}'")
                    break

                action = input("\nAction (read/write/delete): ").strip()
                message = input("Message or index: ").strip()

                timestamp = time.time()
                signature = sign(private_key, f"{timestamp}".encode())

                payload = f"{signature.hex()}||{timestamp}||{role}||{action}||{message}"
                s.sendall(payload.encode())

                response = s.recv(8192).decode()
                print(f"[Server Response] {response}")
                write_client_log(f"User '{username}' performed '{action}' as '{role}'. Response: {response}")

                again = input("Do another action? (y/n): ").strip().lower()
                if again != 'y':
                    print("Session ended.")
                    write_client_log(f"User '{username}' ended session.")
                    break

    except Exception as e:
        print(f"[Client] Error: {e}")
        write_client_log(f"Client Error: {e}")

if __name__ == "__main__":
    while True:
        print("\n===== HIP Client Main Menu =====")
        print("1.  Login")
        print("2.  Sign Up")
        print("3.  Exit")
        choice = input("Select option (1/2/3): ")

        if choice == "1":
            login_and_connect()
        elif choice == "2":
            sign_up()
        elif choice == "3":
            print(" Goodbye!")
            break
        else:
            print(" Invalid choice. Please select 1, 2, or 3.")
