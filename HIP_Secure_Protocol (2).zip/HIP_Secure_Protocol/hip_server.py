# HIP SERVER
import socket
import time
from base64 import urlsafe_b64encode
from cryptography.hazmat.primitives.asymmetric import rsa, padding, dh
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.fernet import Fernet

# === Fixed Diffie-Hellman Parameters ===
p = 2519590847565789349402718324004839857142928212620403202777713783604366202070759555626401852588078440691829064124951508218929855914917618450280848912758392633350850486082503930213321971551843063545500766673908617593525182829993040236049972524680845987273644695848653836736222626099122601693782010622984120347394363468044014408222130009845555658623433121802679051141594073839663606610317485960492215434709781135998552808243411003983272624503216659472011801816960853891007731014711686793579401630497914243974060802491832576930476144771624050435640144319136100035173406172387
g = 2
parameter_numbers = dh.DHParameterNumbers(p, g)
dh_parameters = parameter_numbers.parameters()

# Role-based access control list
ACL = {
    "admin": ["read", "write", "delete"],
    "analyst": ["read", "write"],
    "guest": ["read"]
}

# Log server events with timestamp
def write_server_log(msg):
    with open("server_log.txt", "a", encoding="utf-8") as log:
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        log.write(f"[{timestamp}] {msg}\n")

# Verify digital signature using RSA public key
def verify(public_key, signature, message):
    try:
        public_key.verify(
            signature,
            message,
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
            hashes.SHA256()
        )
        return True
    except:
        return False

# Derive shared session key using DH
def derive_shared_key(private_key, peer_public_key):
    shared_key = private_key.exchange(peer_public_key)
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=b'hip key exchange').derive(shared_key)

# Encrypt and decrypt using Fernet symmetric encryption
def aes_communicate(key, message):
    fernet_key = urlsafe_b64encode(key[:32])
    cipher = Fernet(fernet_key)
    encrypted = cipher.encrypt(message)
    decrypted = cipher.decrypt(encrypted)
    return encrypted, decrypted

# Authorize based on role and requested action
def authorize(role, action):
    return action in ACL.get(role.lower(), [])

# Start the HIP Server
def start_server():
    server_private = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    server_public = server_private.public_key()

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('localhost', 8900))
        s.listen()
        print("[Server] Running on port 9999...")

        while True:
            conn, addr = s.accept()
            with conn:
                print(f"\n[Server] Connected by {addr}")
                write_server_log(f"Connection from {addr}")
                last_timestamp = 0

                # Receive client RSA public key
                client_hi = conn.recv(4096)
                client_public = serialization.load_der_public_key(client_hi)

                # Send server RSA public key
                server_hi_bytes = server_public.public_bytes(
                    serialization.Encoding.DER,
                    serialization.PublicFormat.SubjectPublicKeyInfo
                )
                conn.sendall(server_hi_bytes)

                # DH Key Exchange
                dh_priv = dh_parameters.generate_private_key()
                server_dh_pub = dh_priv.public_key()
                conn.sendall(server_dh_pub.public_bytes(
                    serialization.Encoding.PEM,
                    serialization.PublicFormat.SubjectPublicKeyInfo
                ))

                client_dh_bytes = conn.recv(4096)
                client_dh_pub = serialization.load_pem_public_key(client_dh_bytes)
                session_key = derive_shared_key(dh_priv, client_dh_pub)
                write_server_log(f"Session Key created for {addr}")

                while True:
                    try:
                        data = conn.recv(8192)
                        if not data:
                            print("[Server] Client disconnected.")
                            break

                        data = data.decode().split("||")
                        signature = bytes.fromhex(data[0])
                        timestamp = float(data[1])
                        role = data[2]
                        action = data[3]
                        message = data[4].encode()

                        if timestamp <= last_timestamp:
                            conn.sendall(b"Replay detected!")
                            write_server_log("Replay attack detected")
                            continue
                        elif abs(time.time() - timestamp) > 30:
                            conn.sendall(b"Timestamp expired!")
                            write_server_log("Timestamp expired")
                            continue

                        last_timestamp = timestamp

                        if verify(client_public, signature, f"{timestamp}".encode()):
                            if authorize(role, action):
                                enc, dec = aes_communicate(session_key, message)
                                result = f"[Auth] Encrypted: {enc.decode()} | Decrypted: {dec.decode()}"
                                write_server_log(f"Authorized '{role}' for '{action}'. Msg: {dec.decode()}")
                            else:
                                result = "[Auth] Authorization failed"
                                write_server_log(f"Unauthorized action '{action}' by role '{role}'")
                        else:
                            result = "[Auth] Signature verification failed"
                            write_server_log("Signature verification failed")

                        conn.sendall(result.encode())

                    except Exception as e:
                        print(f"[Server Error] {e}")
                        write_server_log(f"Server Error: {e}")
                        break

if __name__ == "__main__":
    start_server()
